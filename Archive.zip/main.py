# import libraries
import pandas as pd
import matplotlib.pyplot as plt

# read data
data = pd.read_csv('archive/IPL Matches 2008-2020.csv')

# # bat or bowl first in a stadium
# # select stadium
# stadium = data[data.venue.str.contains('Sawai Mansingh Stadium')]
#
# # useful lists
# bat_or_field = ['Bat', 'Field']
# field_first = []
# bat_first = []
#
# # iterate through data
# for index, row in stadium.iterrows():
#     if row[8] == row[10]:
#         if row[9] == 'field':
#             field_first.append(1)
#         else:
#             bat_first.append(1)
#     else:
#         if row[9] == 'field':
#             bat_first.append(1)
#         else:
#             field_first.append(1)
#
# # sum lists
# field_first = sum(field_first)
# bat_first = sum(bat_first)
# outcome = [bat_first, field_first]
#
# # plot data
# plt.bar(bat_or_field, outcome)
# plt.show()


# # teams win more at home or at away
# # select team
# team = 'Royal Challengers Bangalore'
#
# # useful lists
# win_or_lose = ['Win at home', 'Win away', 'Lose at home', 'Lose away']
# win_at_home = []
# lose_at_home = []
# win_away = []
# lose_away = []
# matches_at_home = data[data.team1.str.contains(team)]
# matches_away = data[data.team2.str.contains(team)]
#
# # iterate through data
# for index, row in matches_at_home.iterrows():
#     if row[10] == team:
#         win_at_home.append(1)
#     else:
#         lose_at_home.append(1)
#
# for index, row in matches_away.iterrows():
#     if row[10] == team:
#         win_away.append(1)
#     else:
#         lose_away.append(1)
#
# # sum lists
# win_at_home = sum(win_at_home)
# lose_at_home = sum(lose_at_home)
# win_away = sum(win_away)
# lose_away = sum(lose_away)
# outcomes = [win_at_home, win_away, lose_at_home, lose_away]
#
# # plot data
# plt.bar(win_or_lose, outcomes)
# plt.show()


# most luckiest team
RCB = []
MI = []
CSK = []
SRH = []
RR = []
DC = []
KXIP = []
KKR = []

df = pd.DataFrame(columns=['teams', 'score'])

for index, row in data.iterrows():
    if ((row[11] == 'runs') and (row[12] <= 10)) or ((row[11] == 'wickets') and (row[12] == 1)):
        if 'Royal Challengers Bangalore' == (row[6] or row[7]):
            if 'Royal Challengers Bangalore' == row[10]:
                RCB.append(1)
            else:
                RCB.append(0)
        if 'Mumbai Indians' == (row[6] or row[7]):
            if 'Mumbai Indians' == row[10]:
                MI.append(1)
            else:
                MI.append(0)
        if 'Chennai Super Kings' == (row[6] or row[7]):
            if 'Chennai Super Kings' == row[10]:
                CSK.append(1)
            else:
                CSK.append(0)
        if 'Sunrisers Hyderabad' == (row[6] or row[7]):
            if 'Sunrisers Hyderabad' == row[10]:
                SRH.append(1)
            else:
                SRH.append(0)
        if 'Rajasthan Royals' == (row[6] or row[7]):
            if 'Rajasthan Royals' == row[10]:
                RR.append(1)
            else:
                RR.append(0)
        if ('Delhi Daredevils' or 'Delhi Capitals') == (row[6] or row[7]):
            if 'Delhi Capitals' == row[10]:
                DC.append(1)
            else:
                DC.append(0)
        if 'Kings XI Punjab' == (row[6] or row[7]):
            if 'Kings XI Punjab' == row[10]:
                KXIP.append(1)
            else:
                KXIP.append(0)
        if 'Kolkata Knight Riders' == (row[6] or row[7]):
            if 'Kolkata Knight Riders' == row[10]:
                KKR.append(1)
            else:
                KKR.append(0)
    else:
        pass

df.loc[1] = ['Royal Challengers Bangalore'] + [sum(RCB)/len(RCB)]
df.loc[2] = ['Mumbai Indians'] + [sum(MI)/len(MI)]
df.loc[3] = ['Chennai Super Kings'] + [sum(CSK)/len(CSK)]
df.loc[4] = ['Sunrisers Hyderabad'] + [sum(SRH)/len(SRH)]
df.loc[5] = ['Rajasthan Royals'] + [sum(RR)/len(RR)]
df.loc[6] = ['Delhi Capitals'] + [sum(DC)/len(DC)]
df.loc[7] = ['Kings XI Punjab'] + [sum(KXIP)/len(KXIP)]
df.loc[8] = ['Kolkata Knight Riders'] + [sum(KKR)/len(KKR)]

df = df.sort_values(by='score', ascending=False)

print(df)
