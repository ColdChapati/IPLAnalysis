import pandas as pd

data = pd.read_csv('archive/IPL Ball-by-Ball 2008-2020.csv')

print(data)